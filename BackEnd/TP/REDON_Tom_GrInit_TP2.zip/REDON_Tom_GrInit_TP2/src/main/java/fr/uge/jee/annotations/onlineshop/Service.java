package fr.uge.jee.annotations.onlineshop;

public interface Service {
    public String getDescription();
}
