package fr.uge.jee.annotations.onlineshop;

public interface Insurance extends Service {

}
