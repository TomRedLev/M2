package fr.uge.jee.annotations.onlineshop;

public interface Delivery extends Service {

}
