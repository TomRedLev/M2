package fr.uge.jee.ex2;

public interface MessagePrinter {
    public void printMessage();
}
