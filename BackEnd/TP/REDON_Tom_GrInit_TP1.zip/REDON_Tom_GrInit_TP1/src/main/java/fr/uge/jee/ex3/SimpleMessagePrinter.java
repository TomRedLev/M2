package fr.uge.jee.ex3;

public class SimpleMessagePrinter implements MessagePrinter {
    public void printMessage() {
        System.out.println("Hello World!");
    }
}
