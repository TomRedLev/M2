package fr.uge.jee.ex3;

public interface MessagePrinter {
    public void printMessage();
}
