package fr.uge.jee.onlineshop;

public interface Insurance extends Service {

}
