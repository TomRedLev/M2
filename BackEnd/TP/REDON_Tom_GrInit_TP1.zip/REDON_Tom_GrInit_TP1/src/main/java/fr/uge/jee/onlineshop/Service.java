package fr.uge.jee.onlineshop;

public interface Service {
    public String getDescription();
}
