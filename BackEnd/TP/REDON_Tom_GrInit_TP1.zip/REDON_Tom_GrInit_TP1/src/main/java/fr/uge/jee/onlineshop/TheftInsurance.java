package fr.uge.jee.onlineshop;

public class TheftInsurance implements Insurance {
    @Override
    public String getDescription() {
        return "Theft insurance";
    }
}
