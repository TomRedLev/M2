package fr.uge.jee.ex1;

public class SimpleMessagePrinter {
    public void printMessage() {
        System.out.println("Hello World!");
    }
}
