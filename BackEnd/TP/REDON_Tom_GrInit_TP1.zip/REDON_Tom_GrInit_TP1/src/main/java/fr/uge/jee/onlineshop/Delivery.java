package fr.uge.jee.onlineshop;

public interface Delivery extends Service {

}
