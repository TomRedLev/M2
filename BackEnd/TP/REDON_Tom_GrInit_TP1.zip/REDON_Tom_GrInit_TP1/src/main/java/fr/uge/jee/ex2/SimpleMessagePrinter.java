package fr.uge.jee.ex2;

public class SimpleMessagePrinter implements MessagePrinter {
    public void printMessage() {
        System.out.println("Hello World!");
    }
}
