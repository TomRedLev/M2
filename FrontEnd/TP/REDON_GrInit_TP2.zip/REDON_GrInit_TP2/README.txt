/* TP2 de FrontEnd - Tom REDON - Groupe 2 */
/* tom.redon@edu.univ-eiffel.fr */

J'ai donc tout d'abord réalisé un chrono simple.
Pour cela j'ai suivi les indications données en réalisant la bonne vue et
en associant les fonctions voulues aux clics sur les boutons.

Puis je me suis occupé du passage à l'arrière plan de l'application.
Pour cela, j'ai donc modifié les fonctions onStart et onStop.
J'ai rencontré quelques problèmes au moment de cette partie car
je sauvegardais le temps de départ et non le temps en cours.
J'ai donc modifié cela et tout semble fonctionner.

Ensuite, je me suis occupé de la rotation de l'écran en suivant les
indications données.
J'ai donc rédéfini la fonction onSaveInstanceState et je me suis servi du bundle
renvoyé par la fonction onCreate.

Enfin, j'ai ajouté les conditions de jeu et d'arrêt demandées dans
la partie "Jeu du temps". Le joueur peut donc choisir le temps voulu et aura un
message de défaite si le temps dépasse 50%.

Je n'ai pas réalisé le bonus de son de victoire.

J'ai donc tenté de réaliser les indications du TP et cela m'aura permis de
répondre aux diverses demandes faites dans le TP.
